package com.in2l.in2leisure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class In2leisureApplicationTests {

	@Test
	void contextLoads() {
	}

}
