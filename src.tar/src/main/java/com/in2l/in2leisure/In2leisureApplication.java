package com.in2l.in2leisure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class In2leisureApplication {

	public static void main(String[] args) {
		SpringApplication.run(In2leisureApplication.class, args);
	}

}
