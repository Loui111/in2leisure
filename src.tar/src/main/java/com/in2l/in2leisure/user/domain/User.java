package com.in2l.in2leisure.user.domain;

import com.in2l.in2leisure.common.BaseDateTime;
import com.in2l.in2leisure.common.models.ImageModel;
import com.in2l.in2leisure.common.enums.GenderType;
import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import lombok.Getter;

@Entity
@Getter
public class User extends BaseDateTime {

//  @GeneratedValue   //post할게 아니니 필요가 없지?
  @Id
  private Long id;

  private Long email;
  private Long password;
  private Long userName;
  private Long phone;

  @Enumerated(EnumType.STRING)
  private GenderType gender;

  private Long birthDay;
  private Long address;
  private ImageModel profileImage;
  private LocalDateTime registerDate;      //이건 그...데이터 그걸로 바꿔야 하는데 그....
  private LocalDateTime updateDate;

}
