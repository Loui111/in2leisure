package com.in2l.in2leisure.shop.controller.response;

import lombok.Getter;

@Getter
public class HomeHeaderResponse {


}
