package com.in2l.in2leisure.shop.repository;

import com.in2l.in2leisure.common.models.ImageModel;
import java.util.List;

public interface ImageRepositoryCustom {

  List<ImageModel> getList();

}
