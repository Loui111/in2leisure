package com.in2l.in2leisure.shop.service;

public class MainHomeService {

//  private final HomeRepository homeRepository;
//
//  //get Home Header   //헤더는 거의 static이라 front에서 하는게 맞을듯.
////  public HomeHeaderResponse HomeHeader(){
////
////  }
//
//  //get Main carousel
//  public ImageModel<List> HomeCarousel(){
//
//    return homeRepository.getList();
//
//  }

  //get Type pages

  //get top10

  //get sales

  //get popular

  //get company

  //get footer

}
