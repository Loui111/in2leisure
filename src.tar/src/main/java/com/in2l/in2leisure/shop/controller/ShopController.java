package com.in2l.in2leisure.shop.controller;

import com.in2l.in2leisure.shop.controller.response.MainHomeResponse;
import com.in2l.in2leisure.shop.service.MainHomeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class ShopController {

  private final MainHomeService mainHomeService;

  // 이거 원래 없어야함 (에러때문에 걍 생성해본거)
  public ShopController(MainHomeService mainHomeService) {
    this.mainHomeService = mainHomeService;
  }
  // 이거 원래 없어야함 (에러때문에 걍 생성해본거)


//  @GetMapping("/")
//  public MainHomeResponse mainHome(){   //첫 페이지에 개인화 관련 requestModel이 있어야 할듯.
//    return mainHomeService();
    
//  }


}
