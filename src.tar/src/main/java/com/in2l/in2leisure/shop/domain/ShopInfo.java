package com.in2l.in2leisure.shop.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.Getter;

@Entity
@Getter
public class ShopInfo {

  @Id
  @Column(name = "shopinfo_id")
  private Long id;
}
