package com.in2l.in2leisure.shop.repository;

import com.in2l.in2leisure.common.models.ImageModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HomeRepository extends JpaRepository<ImageModel, Long>, ImageRepositoryCustom {

}
