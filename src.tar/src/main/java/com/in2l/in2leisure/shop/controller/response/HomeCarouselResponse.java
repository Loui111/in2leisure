package com.in2l.in2leisure.shop.controller.response;

public class HomeCarouselResponse<T> {

}
