package com.in2l.in2leisure.shop.domain;

import com.in2l.in2leisure.common.BaseDateTime;
import com.in2l.in2leisure.common.models.ImageModel;
import com.in2l.in2leisure.option.domain.Option;
import com.sun.istack.NotNull;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import lombok.Getter;

@Entity
@Getter
public class Shop extends BaseDateTime {

//  @GeneratedValue   //post를 할게 아니니 이게 필요 없지??
  @Id
  @Column(name = "shop_id")
  private Long id;

  @NotNull
  private String type;

  @NotNull
  private String subType;

//  @OneToMany(mappedBy = "shop", cascade = CascadeType.ALL)
//  private List<Option> optionList = new ArrayList<>();

//  private String subsubType;    //subsub까지 필요할까?

  private String desc;    //이건 CLOB가 되야 하는데?

  private String region;

  private List<ImageModel> frontImage = new ArrayList<>();  //imageModel은 common으로부터 받아옴.
                                                          //frontImage는 슬라이드.

  private ImageModel contentImage;

  private float reviewScore;

  private float rankScore;

  //from BaseDateTime
//  private String createBy;
//  private LocalDateTime createTime;
//  private LocalDateTime updateTime;
}
