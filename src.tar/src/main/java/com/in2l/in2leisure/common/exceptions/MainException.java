package com.in2l.in2leisure.common.exceptions;

import java.util.HashMap;
import java.util.Map;

public abstract class MainException extends  RuntimeException{

  public String errorField;
  public String errorBackMessage;

  public final Map<String, String> validation = new HashMap<>();

  public MainException(String message) {
    super(message);
  }

  public MainException(String message, Throwable cause) {
    super(message, cause);
  }

  public abstract int statusCode(); //상속받는 쪽에서 구현해라 (status 코드 넣어라)

  public void addValidation(String errorField, String errorBackMessage){  //json의 필드네임, 메세지
                                                            //에러 났을때 어떤 필드가 문제고, 어떤 메세지를 줄지 집어넣음.
    this.errorField = errorField;
    this.errorBackMessage = errorBackMessage;
  }
}
