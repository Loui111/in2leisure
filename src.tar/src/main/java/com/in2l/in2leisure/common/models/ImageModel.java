package com.in2l.in2leisure.common.models;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class ImageModel {

  @Id
  @GeneratedValue
  private Long id;

  public String imageName;
  public String imageDesc;

  public String imageBig;     //imagePath
  public String imageMedium;  //imagePath
  public String imageSmall;   //imagePath
}
