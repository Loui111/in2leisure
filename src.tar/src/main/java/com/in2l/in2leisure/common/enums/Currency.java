package com.in2l.in2leisure.common.enums;

public enum  Currency {
  KR, USD, PHP
}
