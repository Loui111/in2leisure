package com.in2l.in2leisure.common.exceptions;

import com.in2l.in2leisure.common.exceptions.response.ErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Slf4j
@ControllerAdvice
public class ExceptionController {

  @ResponseBody
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler(MethodArgumentNotValidException.class)
  public ErrorResponse MethodArgumentNotValidExceptionHandler(MethodArgumentNotValidException e){
    if (e.hasErrors()){
      ErrorResponse response = ErrorResponse.builder()
          .code("400")
          .message("이건 테스트로 만들어 둔거고 Runtime 상속 받아서 제대로 구성할 예정.")
          .build();

      return response;
    }
    else{
      return null;
    }
  }
}
