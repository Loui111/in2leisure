package com.in2l.in2leisure.common.exceptions;

public class InvalidRequest extends MainException{

  private static final String MESSAGE = "잘못된 요청입니다.";

  public InvalidRequest() {
    super(MESSAGE);
  }

  public InvalidRequest(String errorField, String errorBackMessage) { //에러난 부분에 대해 Json으로 리턴주기위함.
    super(MESSAGE);
    addValidation(errorField, errorBackMessage);
  }

  @Override
  public int statusCode() {     //InvalidRequest에 맞는 에러코드를 세팅
    return 400;                 //Override로 public abstract int statusCode() 여기에 넣어줌.
  }
}
