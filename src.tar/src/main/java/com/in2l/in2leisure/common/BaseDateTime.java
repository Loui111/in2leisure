package com.in2l.in2leisure.common;

import java.time.LocalDateTime;

public abstract class BaseDateTime {

  private String createBy;
  private LocalDateTime createTime;
  private LocalDateTime updateTime;
}
