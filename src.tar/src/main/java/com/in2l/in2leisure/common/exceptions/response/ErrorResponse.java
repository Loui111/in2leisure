package com.in2l.in2leisure.common.exceptions.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Builder;
import lombok.Getter;

@Getter
@JsonInclude(value = Include.NON_EMPTY)   //Json포맷을 줄때 empty인건 걍 빼는거.
public class ErrorResponse {

  private final String code;
  private final String message;

  @Builder
  public ErrorResponse(String code, String message) {
    this.code = code;
    this.message = message;
  }
}
