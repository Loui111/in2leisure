package com.in2l.in2leisure.option.domain;

import static javax.persistence.FetchType.LAZY;

import com.in2l.in2leisure.common.enums.Currency;
import com.in2l.in2leisure.shop.domain.Shop;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class Option {

  @Id
  @Column(name = "option_id")
  private Long id;

//  @ManyToOne(fetch = LAZY)
//  @JoinColumn(name = "shop_id")   //이거 생성된 필드명이 다를수도 있음.
//  private Shop shop;

  private String optionName;
  private String optionDesc;
  private String amount;
  private String originPrice;
  private String discountPrice;
  private String discountRate;
  private Currency currency;      //enum
  private Long soldCount;
}
